$(document).ready(function () {
            $('#goproversion').load('content.txt');
            });